#from django.urls import path
#from .views import add_case_view, success_view

#urlpatterns = [
#    path('', add_case_view, name='add_case'),
#    path('success/', success_view, name='success'),
#]

from django.urls import path
from .views import add_case_view, success_view, list_cases_view, search_cases_view

urlpatterns = [
    path('', add_case_view, name='add_case'),
    path('success/', success_view, name='success'),
#    path('list_cases/',list_cases_view, name='list_cases'),
    path('list_cases/', list_cases_view, name='list_cases'),
    path('search_cases/', search_cases_view, name='search_cases'),
]
