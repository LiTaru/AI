from django.db import models

# Create your models here.

class Case(models.Model):
    tapaus_nimi = models.CharField(max_length=200)
    r_ilmoitus = models.CharField(max_length=200)
    TJ = models.CharField(max_length=200)
    tutkija = models.CharField(max_length=200)

    def __str__(self):
        return self.tapaus_nimi  # or any field you want to search by
