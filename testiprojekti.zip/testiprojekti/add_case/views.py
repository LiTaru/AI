#from django.shortcuts import render, redirect
#from .forms import CaseForm
#from django.http import HttpResponse

# Create your views here.

#def add_case_view(request):
#    return render(request, 'add_case/add_case_form.html')



#def add_case_view(request):
#    if request.method == 'POST':
#        form = CaseForm(request.POST)
#        if form.is_valid():
#            form.save()
#            return redirect('success')
#    else:
#        form = CaseForm()
#    return render(request, 'add_case/add_case_form.html', {'form': form})

#def success_view(request):
#    return HttpResponse("Success!")



from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import CaseForm
from .models import Case
from .forms import SearchForm


def add_case_view(request):
    if request.method == 'POST':
        form = CaseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = CaseForm()
    return render(request, 'add_case/add_case_form.html', {'form': form})

def success_view(request):
    return HttpResponse("Success!")



def list_cases_view(request):
    cases = Case.objects.all()
    return render(request, 'add_case/list_cases.html', {'cases': cases})

def search_cases_view(request):
    form = SearchForm(request.GET)
    cases = []
    if form.is_valid():
        search_term = form.cleaned_data['search_term']
        cases = Case.objects.filter(tapaus_nimi__icontains=search_term)
    return render(request, 'add_case/search_cases.html', {'form': form, 'cases': cases})
