from django import forms
from .models import Case

class CaseForm(forms.ModelForm):
    class Meta:
        model = Case
        fields = ['tapaus_nimi', 'r_ilmoitus', 'TJ', 'tutkija']


class SearchForm(forms.Form):
    search_term = forms.CharField(max_length=200)
